"""
Vumi scalable text messaging engine.
"""

__version__ = "0.6.17"
