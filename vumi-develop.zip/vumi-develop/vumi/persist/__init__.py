"""The vumi.persist API."""
