from vumi.codecs.vumi_codecs import VumiCodec

__all__ = ['VumiCodec']
