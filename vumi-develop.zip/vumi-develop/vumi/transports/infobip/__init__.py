"""Infobip transport."""

from vumi.transports.infobip.infobip import InfobipTransport, InfobipError

__all__ = ['InfobipTransport', 'InfobipError']
