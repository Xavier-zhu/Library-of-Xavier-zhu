from vumi.transports.apposit.apposit import AppositTransport

__all__ = ['AppositTransport']
