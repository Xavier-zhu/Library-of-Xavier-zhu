from vumi.transports.devnull.devnull import DevNullTransport

__all__ = ['DevNullTransport']
