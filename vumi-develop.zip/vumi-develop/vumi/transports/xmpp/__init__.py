"""
Vumi XMPP transport.
"""

from vumi.transports.xmpp.xmpp import XMPPTransport


__all__ = ['XMPPTransport']
