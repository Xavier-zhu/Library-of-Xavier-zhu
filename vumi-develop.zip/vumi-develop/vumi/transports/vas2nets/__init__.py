"""
Vas2Nets HTTP SMS API.
"""

from vumi.transports.vas2nets.vas2nets import Vas2NetsTransport


__all__ = ['Vas2NetsTransport']
