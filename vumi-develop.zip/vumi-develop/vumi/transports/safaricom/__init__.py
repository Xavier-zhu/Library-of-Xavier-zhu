"""
Safaricom HTTP USSD API.
"""

from vumi.transports.safaricom.safaricom import SafaricomTransport


__all__ = ['SafaricomTransport']
