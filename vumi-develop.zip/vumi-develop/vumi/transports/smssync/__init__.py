"""SMSSync (http://smssync.ushahidi.com/) transport for android devices"""

from vumi.transports.smssync.smssync import SingleSmsSync, MultiSmsSync

__all__ = ['SingleSmsSync', 'MultiSmsSync']
