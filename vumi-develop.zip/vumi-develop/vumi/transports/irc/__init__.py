"""IRC Transport."""

from vumi.transports.irc.irc import IrcTransport

__all__ = ['IrcTransport']
