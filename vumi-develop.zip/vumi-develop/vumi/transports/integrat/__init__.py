"""
Integrat HTTP USSD API.
"""

from vumi.transports.integrat.integrat import IntegratTransport


__all__ = ['IntegratTransport']
