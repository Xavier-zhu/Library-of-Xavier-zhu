"""Synchronous HTTP RPC-based message transports."""

from vumi.transports.httprpc.httprpc import HttpRpcTransport

__all__ = ['HttpRpcTransport']
