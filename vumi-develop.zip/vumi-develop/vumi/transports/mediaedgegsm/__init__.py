from vumi.transports.mediaedgegsm.mediaedgegsm import MediaEdgeGSMTransport


__all__ = ['MediaEdgeGSMTransport']
