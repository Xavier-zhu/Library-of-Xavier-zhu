class WeChatException(Exception):
    pass


class WeChatApiException(WeChatException):
    pass


class WeChatParserException(WeChatException):
    pass
