from vumi.transports.wechat.wechat import WeChatTransport

__all__ = ['WeChatTransport']
