"""
Mediafone Cameroun HTTP SMS API.
"""

from vumi.transports.mediafonemc.mediafonemc import MediafoneTransport


__all__ = ['MediafoneTransport']
