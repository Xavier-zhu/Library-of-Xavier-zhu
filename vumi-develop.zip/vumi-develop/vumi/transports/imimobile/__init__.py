"""
ImiMobile HTTP USSD API.
"""

from vumi.transports.imimobile.imimobile_ussd import ImiMobileUssdTransport


__all__ = ['ImiMobileUssdTransport']
