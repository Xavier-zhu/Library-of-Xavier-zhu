from vumi.transports.vumi_bridge.vumi_bridge import GoConversationTransport

__all__ = [
    'GoConversationTransport',
]
