"""Mtech USSD transport."""

from vumi.transports.mtech_ussd.mtech_ussd import MtechUssdTransport

__all__ = ['MtechUssdTransport']
