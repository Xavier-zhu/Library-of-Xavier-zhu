"""TruTeq transport."""

from vumi.transports.truteq.truteq import TruteqTransport

__all__ = ['TruteqTransport']
