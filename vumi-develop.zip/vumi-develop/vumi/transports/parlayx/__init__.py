"""
ParlayX SOAP API.
"""
from vumi.transports.parlayx.parlayx import ParlayXTransport


__all__ = ['ParlayXTransport']
