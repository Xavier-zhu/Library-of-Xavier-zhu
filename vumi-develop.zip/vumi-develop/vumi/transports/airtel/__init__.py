from vumi.transports.airtel.airtel import AirtelUSSDTransport

__all__ = ['AirtelUSSDTransport']
