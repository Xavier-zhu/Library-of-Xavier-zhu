"""
Dmark_ transports.

.. _Dmark: http://dmarkmobile.com/.
"""

from vumi.transports.dmark.dmark_ussd import DmarkUssdTransport


__all__ = ['DmarkUssdTransport']
