from vumi.transports.mxit.mxit import MxitTransport

__all__ = ['MxitTransport']
