"""
MTN Nigeria USSD transport.
"""

from vumi.transports.mtn_nigeria.mtn_nigeria_ussd import (
    MtnNigeriaUssdTransport)


__all__ = ['MtnNigeriaUssdTransport', 'XmlOverTcpClient']
