mkdir -p smppsim && \
cd smppsim && \
wget http://www.seleniumsoftware.com/downloads/SMPPSim.tar.gz && \
tar zxf SMPPSim.tar.gz
