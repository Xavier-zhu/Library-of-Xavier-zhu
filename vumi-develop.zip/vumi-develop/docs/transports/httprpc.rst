HTTP RPC
========

Base class for constructing HTTP-based transports.


HTTP RPC base class
^^^^^^^^^^^^^^^^^^^

.. automodule:: vumi.transports.httprpc.httprpc
   :members:
   :show-inheritance:
