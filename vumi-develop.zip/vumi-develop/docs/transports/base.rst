Base class for transports
=========================

A base class you should extend when writing transports.

Transport
^^^^^^^^^

.. py:module:: vumi.transports.base

.. autoclass:: TransportConfig

.. autoclass:: Transport
   :members:
