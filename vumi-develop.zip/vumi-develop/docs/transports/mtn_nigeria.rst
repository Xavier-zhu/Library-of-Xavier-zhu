MTN Nigeria
===========


MTN Nigeria USSD Transport
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: vumi.transports.mtn_nigeria.mtn_nigeria_ussd
   :members:
   :show-inheritance:
