Mxit
====


Mxit Transport
^^^^^^^^^^^^^^

.. automodule:: vumi.transports.mxit.mxit
   :members:
   :show-inheritance:
