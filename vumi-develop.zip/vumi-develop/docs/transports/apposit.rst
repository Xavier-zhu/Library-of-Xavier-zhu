Apposit
=======


Apposit Transport
^^^^^^^^^^^^^^^^^

.. automodule:: vumi.transports.apposit.apposit
   :members:
   :show-inheritance:
