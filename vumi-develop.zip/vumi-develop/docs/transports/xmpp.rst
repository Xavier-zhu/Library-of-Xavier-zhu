XMPP
====


XMPP Transport
^^^^^^^^^^^^^^

.. automodule:: vumi.transports.xmpp.xmpp
   :members:
   :show-inheritance:
