IRC
===


IRC Transport
^^^^^^^^^^^^^

.. automodule:: vumi.transports.irc.irc
   :members:
   :show-inheritance:
