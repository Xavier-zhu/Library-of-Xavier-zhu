Dev Null
========


Dev Null Transport
^^^^^^^^^^^^^^^^^^

.. automodule:: vumi.transports.devnull.devnull
   :members:
   :show-inheritance:
