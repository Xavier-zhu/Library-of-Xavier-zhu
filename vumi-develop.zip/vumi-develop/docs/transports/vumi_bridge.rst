Vumi Go bridge
==============


Vumi Bridge Transport
^^^^^^^^^^^^^^^^^^^^^

.. automodule:: vumi.transports.vumi_bridge.vumi_bridge
   :members:
   :show-inheritance:
