ParlayX
=======


ParlayX SMS Transport
^^^^^^^^^^^^^^^^^^^^^

.. automodule:: vumi.transports.parlayx.parlayx
   :members:
   :show-inheritance:
