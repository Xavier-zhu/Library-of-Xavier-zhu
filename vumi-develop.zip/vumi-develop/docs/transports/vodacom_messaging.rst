Vodacom Messaging
=================


Vodacom Messaging Transport
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: vumi.transports.vodacom_messaging.vodacom_messaging
   :members:
   :show-inheritance:
