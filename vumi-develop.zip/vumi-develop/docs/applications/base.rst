Base class for applications
===========================

A base class you should extend when writing applications.

Application
^^^^^^^^^^^

.. py:module:: vumi.application.base

.. autoclass:: ApplicationConfig

.. autoclass:: ApplicationWorker
   :members:
