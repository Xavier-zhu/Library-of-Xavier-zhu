RapidSMS Relay
==============

Calls out to an application implemented in RapidSMS.

RapidSMS Relay
^^^^^^^^^^^^^^

.. py:module:: vumi.application.rapidsms_relay

.. autoclass:: RapidSMSRelayConfig

.. autoclass:: RapidSMSRelay
