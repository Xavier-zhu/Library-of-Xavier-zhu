HTTP Relay
==========

Calls out to an external HTTP API that implements application logic
and provides a similar API for application logic to call when sending
messages.

HTTP Relay
^^^^^^^^^^

.. py:module:: vumi.application.http_relay

.. autoclass:: HTTPRelayConfig

.. autoclass:: HTTPRelayApplication
